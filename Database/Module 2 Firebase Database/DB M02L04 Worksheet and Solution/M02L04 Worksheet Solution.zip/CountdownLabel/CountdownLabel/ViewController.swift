//
//  ViewController.swift
//  CountdownLabel
//
//  Created by Christopher Ching on 2018-05-04.
//  Copyright © 2018 CodeWithChris. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        /*
        var timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (t) in

            self.label.alpha += 0.1

            if self.label.alpha >= 1 {
                t.invalidate()
            }
        }
         */

        UIView.animate(withDuration: 1, animations: {
            
            self.label.alpha = 1
            
        }) { (completed) in
            
            self.label.text = "done"
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

